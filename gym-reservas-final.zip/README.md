# Sistema de Reservas para un Gimnasio 🏋️‍♀️

Este proyecto permite a los usuarios registrarse, iniciar sesión y reservar clases en un gimnasio. Los administradores pueden crear, editar y eliminar clases.

## 🚀 Tecnologías Utilizadas

### Frontend
- HTML5
- CSS3
- JavaScript

### Backend
- Node.js
- Express.js
- JavaScript

### Base de Datos
- MariaDB

### ORM
- Sequelize

## 📁 Estructura del Repositorio

- `/frontend`: Código del cliente (interfaz)
- `/backend`: Servidor (API, lógica de negocio)
- `/docs`: Diagramas (DER, Mockups, CRUD)
- `README.md`: Documentación del proyecto

## 👥 Integrantes
- Juan Pérez
- Ana Rodríguez
- Luis Gómez
